#ifndef PRODUCTTYPE_H
#define PRODUCTTYPE_H

enum ProductType{
    FURNITURE,
    ELECTRONICS,
    TOYS,
    NA
};

#endif // PRODUCTTYPE_H2

