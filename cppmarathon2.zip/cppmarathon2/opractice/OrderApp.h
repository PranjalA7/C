#ifndef ORDERAPP_H
#define ORDERAPP_H

enum OrderApp{
    AMAZON,
    FLIPKART,
    MYNTRA
};

#endif // ORDERAPP_H