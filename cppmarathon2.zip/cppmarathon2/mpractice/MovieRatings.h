// enum for movie ratings

#ifndef MOVIERATINGS_H
#define MOVIERATINGS_H

enum MovieRatings{
    U,
    UA,
    R,
    A
};

#endif // MOVIERATINGS_H