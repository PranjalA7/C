#ifndef TRAVELCLASS_H
#define TRAVELCLASS_H

enum class TravelClass
{
    FIRST,
    SLEEPER,
    AC2TIER,
    AC3TIER,
    AC3ECONOMY
};

#endif // TRAVELCLASS_H

//int a; 
// a =10;

//print(a);