#ifndef CARCATEGORY_H
#define CARCATEGORY_H

enum class carCategory
{
    SUV,
    HatchBack,
    Sedan
};

#endif // CARCATEGORY_H