#ifndef TRAVEL_CLASS_H
#define TRAVEL_CLASS_H

enum class TravelClass{

    FIRST,
    SLEEPER,
    AC2TIER,
    AC3TIER,
    AC3ECONOMY

};

#endif // TRAVEL_CLASS_H
