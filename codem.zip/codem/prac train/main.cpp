#include<iostream>
#include "pTrain.h"
#include "Travel_class.h"

int main()
{
    pTrain arr[5];
    int size = 5;

    showMenu(arr, size);
    return 0;
}