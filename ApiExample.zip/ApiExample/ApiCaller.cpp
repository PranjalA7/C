#include "ApiCaller.h"

size_t writeFunction(void *ptr, size_t size, size_t nmemb, std::string* data) {
    data->append((char*) ptr, size * nmemb);
    return size * nmemb;
}

/*
    constructor that takes only url 
    maps url and initializes session
*/
ApiCaller::ApiCaller(std::string url)
    : _end_point( url ), 

    _curl_session_object_handle(curl_easy_init()),
    
    _response { std::make_shared<Response>()  }
     {}

/*
    takes url and header params from user
    Uses delegation to call the constructor above and assigns header to _request_header
*/

ApiCaller::ApiCaller(std::string url, std::string header)
     : ApiCaller(url) 
{
    _request_header = header;
}

void ApiCaller::ExecuteApiCall()
{
    /*
        set your preferred end point

        a) pass ession object
        b) select option as CURLOPT_URL
        c) specify url
    */

    curl_easy_setopt(
        _curl_session_object_handle, 
        CURLOPT_URL,
        _end_point //DO SOMETHING HERE TO GET C_STYLE ARRAY INSTEAD OF A STRING
    );


    /*
        we need a function that can read response receive and write it 
        (byte-by-byte) into response_string variable.
        This function (writeFunction is defined above)
    */

    curl_easy_setopt(
        _curl_session_object_handle, 

        CURLOPT_WRITEFUNCTION, 
        
        //DO SOMETHING HERE TO CONVERT THIS LAMBDA INTO A FUNCTION POINTER
        [](void *ptr, size_t size, size_t nmemb, std::string* data) {
            data->append((char*) ptr, size * nmemb);
            return size * nmemb;
        }
    );

    /*
        specify where data has to be written (address of response string)
    */

    curl_easy_setopt(
        _curl_session_object_handle,  //session handle
        CURLOPT_WRITEDATA,  //name of setting (option being used)
        
        /*
            DO SOMETHING HERE TO GET THE LOCATION OF ACTUAL VARIABLE _reponse_string
            from Response.h
        */
        & _response->responseString() 
    );

    /*
        specify where header data comes from (location of header_string)
    */
    curl_easy_setopt(
        _curl_session_object_handle, 
        CURLOPT_HEADERDATA, 
        &_request_header
    );
   
    /*
        after all settings above, finally execute curl 
        with on all options provided
    */

    curl_easy_perform(_curl_session_object_handle);

    /*
        WRITE ESSENTIAL CODE TO GET RESPONSE STATUS CODE AND ELAPSED TIME
    */

    /*
        clean up session. Reset everything before next request is to be made
    */
    
    curl_easy_cleanup(_curl_session_object_handle);
    _curl_session_object_handle = nullptr;


}

std::ostream &operator<<(std::ostream &os, const ApiCaller &rhs) {
    os << "_end_point: " << rhs._end_point
       << " _response: " << *rhs._response;
    return os;
}
